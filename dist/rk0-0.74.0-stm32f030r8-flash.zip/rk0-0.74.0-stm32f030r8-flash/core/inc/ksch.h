/* SPDX-License-Identifier: Apache-2.0 */
/******************************************************************************/
/**                                                                           */
/** RK0 - The Embedded Real-Time Kernel '0'                                   */
/** (C) 2026 Antonio Giacomelli <dev@kernel0.org>                             */
/**                                                                           */
/** VERSION: V0.74.0                                                          */
/**                                                                           */
/** You may obtain a copy of the License at :                                 */
/** http://www.apache.org/licenses/LICENSE-2.0                                */
/**                                                                           */
/******************************************************************************/
#ifndef RK_SCH_H
#define RK_SCH_H
#ifdef __cplusplus
{
#endif
#include <kenv.h>
#include <kcoredefs.h>
#include <kcommondefs.h>
#include <kobjs.h>
#include <klist.h>
#include <kstring.h>
/* Globals */

extern RK_TCB* RK_gRunPtr; /* Pointer to the running TCB */
extern RK_TCB RK_gTcbs[RK_NTHREADS]; /* Pool of RK_gTcbs */
extern volatile RK_FAULT RK_gFaultID; /* Fault ID */
extern UINT RK_gIdleStack[RK_CONF_IDLE_STACKSIZE]; /* Stack for idle task */
extern UINT RK_gPostProcStack[RK_CONF_POSTPROC_STACKSIZE];
extern RK_TCBQ RK_gReadyQueue[RK_RDYQSIZ]; /* Table of ready queues */
extern volatile ULONG RK_gReadyBitmask;
extern volatile ULONG RK_gReadyPos;
extern volatile UINT RK_gPendingCtxtSwtch;
extern volatile UINT RK_gSchLock;

/* internal return values */
#ifndef RK_ERR_RESCHED_PENDING
#define RK_ERR_RESCHED_PENDING                ((RK_ERR)900)
#endif
#ifndef RK_ERR_RESCHED_NOT_NEEDED
#define RK_ERR_RESCHED_NOT_NEEDED            ((RK_ERR)901)
#endif
#ifndef RK_CONF_MIN_PRIO
#define RK_CONF_MIN_PRIO 31
#endif

VOID kSchLock(VOID);
VOID kSchUnlock(VOID);
VOID kPendCtxSwtch(VOID);
VOID kSwtch(VOID);
VOID kInit(VOID);
VOID kYield(VOID);
#ifndef kPreemptEnable
#define kPreemptEnable kSchUnlock
#endif
#ifndef kPreemptDisable
#define kPreemptDisable kSchLock
#endif

/* Task queue management */
RK_ERR kTCBQInit(RK_TCBQ *const);
RK_ERR kTCBQEnq(RK_TCBQ *const, RK_TCB *const);
RK_ERR kTCBQJam(RK_TCBQ *const, RK_TCB *const);
RK_ERR kTCBQDeq(RK_TCBQ *const, RK_TCB **const);
RK_ERR kTCBQRem(RK_TCBQ *const, RK_TCB **const);
RK_TCB *kTCBQPeek(RK_TCBQ *const);
RK_ERR kTCBQEnqByPrio(RK_TCBQ *const, RK_TCB *const);
RK_ERR kReschedTask(RK_TCB *);
RK_ERR kReschedRunning(VOID);
RK_BOOL kTaskUpdateEffectivePrio(RK_TCB *const);
VOID kTaskUpdateEffectivePrioChain(RK_TCB *const);
RK_ERR kReadySwtch(RK_TCB *const);
RK_ERR kReadyNoSwtch(RK_TCB *const);
RK_ERR kTaskInit(RK_TASK_HANDLE *,
                   const RK_TASKENTRY, VOID *,
                   CHAR *const, RK_STACK *const,
                   const ULONG, const RK_PRIO,
                   const RK_OPTION);
#if (RK_CONF_DYNAMIC_TASK == ON)
RK_ERR kTaskSpawn(RK_DYNAMIC_TASK_ATTR const * ,
                  RK_TASK_HANDLE * );

RK_ERR kTaskTerminate(RK_TASK_HANDLE *);
RK_ERR kTaskTerminateSelf(VOID);
#endif

RK_TASK_HANDLE kTaskGetRunningHandle(VOID);
RK_TID kTaskGetID(RK_TASK_HANDLE taskHandle);
RK_ERR kTaskGetName(RK_TASK_HANDLE taskHandle, CHAR *buf);
RK_PRIO kTaskGetPrio(RK_TASK_HANDLE taskHandle);



#ifdef __cplusplus
}
#endif

#endif /* KSCH_H */
