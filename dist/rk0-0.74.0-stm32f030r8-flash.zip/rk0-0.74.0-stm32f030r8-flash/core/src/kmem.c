/* SPDX-License-Identifier: Apache-2.0 */
/******************************************************************************/
/**                                                                           */
/** RK0 - The Embedded Real-Time Kernel '0'                                   */
/** (C) 2026 Antonio Giacomelli <dev@kernel0.org>                             */
/**                                                                           */
/** VERSION: V0.74.0                                                          */
/**                                                                           */
/** You may obtain a copy of the License at :                                 */
/** http://www.apache.org/licenses/LICENSE-2.0                                */
/**                                                                           */
/******************************************************************************/
/******************************************************************************/
/* COMPONENT: PARTITION MEMORY ALLOCATOR                                      */
/******************************************************************************/

#define RK_SOURCE_CODE

#include <kmem.h>
#include <ksch.h>
#include <ktrace.h>

#if (RK_CONF_ERR_CHECK == ON)

/* double free? */
RK_FORCE_INLINE
static inline RK_BOOL kMemPartitionFreeListContains_(RK_MEM_PARTITION const *const kobj,
                                              VOID const *const blockPtr)
{
    BYTE *freeBlockPtr = kobj->freeListPtr;

    for (ULONG i = 0UL; (i < kobj->nFreeBlocks) && (freeBlockPtr != NULL);
         i++)
    {
        if ((VOID const *)freeBlockPtr == blockPtr)
        {
            return (RK_TRUE);
        }

        freeBlockPtr = *(BYTE **)freeBlockPtr;
    }

    return (RK_FALSE);
}
#endif

RK_FORCE_INLINE
static inline RK_BOOL kMemPartitionBlockValid_(
    RK_MEM_PARTITION const *const kobj,
    VOID const *const blockPtr)
{
    BYTE const *const poolStartPtr = kobj->poolPtr;
    BYTE const *const poolEndPtr =
        poolStartPtr + (kobj->blkSize * kobj->nMaxBlocks);
    BYTE const *const freeBytePtr = (BYTE const *)blockPtr;

    if ((freeBytePtr < poolStartPtr) || (freeBytePtr >= poolEndPtr))
    {
        return (RK_FALSE);
    }

    ULONG const diff = (ULONG)(freeBytePtr - poolStartPtr);
    return (((diff % kobj->blkSize) == 0UL) ? RK_TRUE : RK_FALSE);
}

RK_ERR kMemPartitionInit(RK_MEM_PARTITION *const kobj, VOID *memPoolPtr,
                         ULONG blkSize, ULONG const numBlocks)
{
    RK_CR_AREA

    RK_CR_ENTER

    if ((kobj == NULL) || (memPoolPtr == NULL))
    {
#if (RK_CONF_ERR_CHECK == ON)
        K_ERR_HANDLER(RK_FAULT_OBJ_NULL);
#endif
        RK_CR_EXIT
        return (RK_ERR_OBJ_NULL);
    }

#if (RK_CONF_ERR_CHECK == ON)

    if (kobj->init == RK_TRUE)
    {
        K_ERR_HANDLER(RK_FAULT_OBJ_DOUBLE_INIT);
        RK_CR_EXIT
        return (RK_ERR_OBJ_DOUBLE_INIT);
    }

#endif

    if ((blkSize == 0UL) || (numBlocks == 0UL) ||
        (blkSize > (RK_ULONG_MAX - (RK_WORD_SIZE - 1UL))) ||
        (((ULONG)memPoolPtr & (RK_WORD_SIZE - 1UL)) != 0UL))
    {
#if (RK_CONF_ERR_CHECK == ON)
        K_ERR_HANDLER(RK_FAULT_INVALID_PARAM);
#endif
        RK_CR_EXIT
        return (RK_ERR_INVALID_PARAM);
    }

    /* rounds up to next multiple of 4*/
    blkSize = ((blkSize + RK_WORD_SIZE - 1) & ~(RK_WORD_SIZE - 1));

    /* initialise freelist of blocks */

    ULONG *blockPtr = (ULONG *)memPoolPtr;
    VOID **nextAddrPtr = (VOID **)memPoolPtr; /* next block address */

    for (ULONG i = 0; i < numBlocks - 1; i++)
    {
        ULONG incSizeWord = blkSize / RK_WORD_SIZE;
        blockPtr += incSizeWord;
        /* save blockPtr addr as the next */
        *nextAddrPtr = (VOID *)blockPtr;
        /* update  */
        nextAddrPtr = (VOID **)(blockPtr);
    }
    *nextAddrPtr = NULL;

    /* init the control block */
    kobj->blkSize = blkSize;
    kobj->nMaxBlocks = numBlocks;
    kobj->nFreeBlocks = numBlocks;
    kobj->freeListPtr = memPoolPtr;
    kobj->poolPtr = memPoolPtr;
    RK_ERR const queueErr = kTCBQInit(&kobj->waitingQueue);
    if (queueErr != RK_ERR_SUCCESS)
    {
        RK_CR_EXIT
        return (queueErr);
    }
#if ((RK_CONF_ASYNCH_MESG == ON) && (RK_CONF_MESG_QUEUE == ON))
    /*
     * A plain memory partition has no message ceiling. kMesgPoolInit()
     * enables these fields only for asynchronous direct-message pools.
     */
    kobj->mesgPrioCeiling = RK_MESG_PRIO_CEILING_NONE;
    kobj->mesgPrioCeilingEnabled = RK_FALSE;
#endif
    kobj->init = RK_TRUE;
    kobj->objID = RK_MEMALLOC_KOBJ_ID;
    kobj->objName[0] = '\0';
    kTraceRegisterObject(kobj, RK_MEMALLOC_KOBJ_ID);
    RK_CR_EXIT
    return (RK_ERR_SUCCESS);
}

VOID *kMemPartitionAlloc(RK_MEM_PARTITION *const kobj)
{

    RK_CR_AREA
    RK_CR_ENTER

#if (RK_CONF_ERR_CHECK == ON)

    if (kobj == NULL)
    {
        K_ERR_HANDLER(RK_FAULT_OBJ_NULL);
        RK_CR_EXIT
        return (NULL);
    }

    if (kobj->objID != RK_MEMALLOC_KOBJ_ID)
    {
        K_ERR_HANDLER(RK_FAULT_INVALID_OBJ);
        RK_CR_EXIT
        return (NULL);
    }

    if (!kobj->init)
    {
        K_ERR_HANDLER(RK_FAULT_OBJ_NOT_INIT);
        RK_CR_EXIT
        return (NULL);
    }

#endif

    VOID *allocPtr = NULL;

    if (kobj->nFreeBlocks > 0)
    {
        allocPtr = kobj->freeListPtr;
        RK_BARRIER
        kobj->nFreeBlocks -= 1;
        kobj->freeListPtr = *(VOID **)allocPtr;
        kTraceRecordObject(kobj, RK_TRACE_OP_ALLOC, RK_ERR_SUCCESS,
                           kobj->nFreeBlocks);
    }
    else
    {
        kTraceRecordObject(kobj, RK_TRACE_OP_ALLOC, RK_ERR_BUFFER_EMPTY,
                           kobj->nFreeBlocks);
    }
    RK_CR_EXIT
    return (allocPtr);
}

RK_ERR kMemPartitionFree(RK_MEM_PARTITION *const kobj, VOID *blockPtr)
{

    RK_CR_AREA
    RK_CR_ENTER

#if (RK_CONF_ERR_CHECK == ON)

    if (kobj == NULL || blockPtr == NULL)
    {
        K_ERR_HANDLER(RK_FAULT_OBJ_NULL);
        RK_CR_EXIT
        return (RK_ERR_OBJ_NULL);
    }

    if (kobj->objID != RK_MEMALLOC_KOBJ_ID)
    {
        K_ERR_HANDLER(RK_FAULT_INVALID_OBJ);
        RK_CR_EXIT
        return (RK_ERR_INVALID_OBJ);
    }

    if (!kobj->init)
    {
        K_ERR_HANDLER(RK_FAULT_OBJ_NOT_INIT);
        RK_CR_EXIT
        return (RK_ERR_OBJ_NOT_INIT);
    }

    /* all blocks belonging to this pool are free */
    RK_BOOL allFree = (kobj->nFreeBlocks == kobj->nMaxBlocks);
    if ((kMemPartitionBlockValid_(kobj, blockPtr) == RK_FALSE) || allFree ||
        /* check for double free */
        (kMemPartitionFreeListContains_(kobj, blockPtr) != RK_FALSE))
    {
        K_ERR_HANDLER(RK_FAULT_MEM_FREE);
        RK_CR_EXIT
        return (RK_ERR_MEM_FREE);
    }

#endif

    *(VOID **)blockPtr = kobj->freeListPtr;
    kobj->freeListPtr = blockPtr;
    kobj->nFreeBlocks += 1;
    kTraceRecordObject(kobj, RK_TRACE_OP_FREE, RK_ERR_SUCCESS,
                       kobj->nFreeBlocks);
    RK_CR_EXIT
    return (RK_ERR_SUCCESS);
}
